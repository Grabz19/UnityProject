﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PanelContainerResourcesScript : MonoBehaviour {
	[SerializeField] private GameObject prefabPanelResource;
	
	private List<PanelResourceScript> panelResources;
	
	private GameControllerScript gameController;
	
	public void Awake() {
		panelResources = new List<PanelResourceScript>();
		
		gameController = GameObject.FindGameObjectsWithTag("GameController")[0].GetComponent<GameControllerScript>();
	}
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		Game.Resource[] resources = gameController.GetResources();
		
		//this is a shitty solution
		if(panelResources.Count != resources.Length) {
			for(int i = 0; i < panelResources.Count; i++) {
				Destroy(panelResources[i].gameObject);
			}
			for(int i = 0; i < panelResources.Count; i++) {
				panelResources.Remove(panelResources[i]);
				i--;
			}
			
			for(int i = 0; i < resources.Length; i++) {
				GameObject obj = Instantiate(prefabPanelResource);
				
				RectTransform transform = obj.GetComponent<RectTransform>();
				transform.localPosition -= new Vector3(0, i * transform.sizeDelta.y, 0);
				transform.SetParent(this.transform, false);
				
				PanelResourceScript panelRes = obj.GetComponent<PanelResourceScript>();
				
				panelResources.Add(panelRes);
				
				/*panelRes.SetName(resources[i].GetName());
				panelRes.SetOwned(resources[i].GetOwned());
				panelRes.SetMax(resources[i].GetMax());*/
			}
		}
		
		for(int i = 0; i < resources.Length; i++) {
			panelResources[i].SetName(resources[i].GetName());
			panelResources[i].SetOwned(resources[i].GetOwned());
			panelResources[i].SetMax(resources[i].GetMax());
		}
	}
}
