﻿using UnityEngine;
using System;
using System.Collections;

using Game;

public class GameControllerScript : MonoBehaviour {
	[SerializeField] private Game.Resource[] resources;
	
	// Use this for initialization
	public void Start () {
	
	}
	
	// Update is called once per frame
	public void Update () {
		//test stuff
		//randomly add resources
		
		try {
			if(resources[0] != null) {
				resources[0].SetOwned(resources[0].GetOwned() + 1);
			}
			if(resources[1] != null) {
				resources[1].SetOwned(resources[1].GetOwned() + 2);
			}
			if(resources[2] != null) {
				resources[2].SetOwned(resources[2].GetOwned() + 5);
			}
		}
		catch(Exception e){};
	}
	
	public Game.Resource[] GetResources() {
		return resources;
	}
}
