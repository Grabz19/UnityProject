﻿using UnityEngine;
using System.Collections;

public class PanelResourceScript : MonoBehaviour {
	[SerializeField] private UnityEngine.UI.Text textResource;
	[SerializeField] private UnityEngine.UI.Text textOwned;
	[SerializeField] private UnityEngine.UI.Text textMax;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	public void SetName(string name) {
		textResource.text = name;
	}
	
	public void SetOwned(float owned) {
		textOwned.text = owned.ToString();
	}
	
	public void SetMax(float max) {
		textMax.text = max.ToString();
	}
}
