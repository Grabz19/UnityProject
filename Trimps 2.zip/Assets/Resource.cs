﻿using UnityEngine;
using System.Collections;

namespace Game {
	[System.Serializable]
	public class Resource {
		[SerializeField] private string name;
		[SerializeField] private float owned;
		[SerializeField] private float max;
		
		public void SetName(string n) {
			name = n;
		}
		
		public void SetOwned(float o) {
			owned = o;
			
			if(owned > max)
				owned = max;
		}
		
		public void SetMax(float m) {
			max = m;
		}
		
		public string GetName() {
			return name;
		}
		
		public float GetOwned() {
			return owned;
		}
		
		public float GetMax() {
			return max;
		}
	}
}
